export default function Hero() {
  return (
    <section className="py-24 px-5 text-center" style={{ background: 'radial-gradient(circle, #0a1629 0%, #040d1a 100%)' }}>
      <div className="flex justify-center items-center w-full pb-10">
        <div className="max-w-xs w-4/5 h-auto bg-gray-800 rounded-lg flex items-center justify-center text-gray-400 text-sm">
          [Summit Logo]
        </div>
      </div>
      <h1 className="text-5xl md:text-6xl mb-5 text-white font-bold">The 2026 Mandate</h1>
      <p className="max-w-3xl mx-auto mb-10 text-xl text-gray-400">
        A high-stakes residency for leaders who refuse to let technology outpace their culture. Master AI integration without sacrificing human excellence.
      </p>
      <a
        href="#pricing"
        className="inline-block py-4 px-8 font-bold rounded-md transition-all hover:opacity-90"
        style={{ background: 'var(--gold)', color: 'var(--dark)' }}
      >
        Join the Residency
      </a>
    </section>
  );
}
